"""カメラから見た画面を小さな JPEG にする（iPhone に送るため）。

- 3D ビューの「ヘッダー（上の細い帯）」が描かれるときに呼ぶ。
  ヘッダーは描き直しが軽いので、ビューポート本体を何度も描き直さずに済む。
- 画面外（GPUOffScreen）にカメラの見た目だけを描く（グリッドや選択の枠は消す）。
- JPEG は Blender の Image に入れて一時ファイルに保存して作る（追加のライブラリは要らない）。
"""

import os
import struct
import tempfile

import bpy
import gpu
import numpy as np

# 画質の選択肢: 名前 → 横の画素数（縦はシーンの出力の縦横比に合わせる）
SIZES = {
    "SMALL": 480,
    "MEDIUM": 640,
    "LARGE": 960,
}
JPEG_QUALITY = 60
MAX_PACKET = 60000  # UDP の1パケットに入る大きさ（余裕を見て）
MAGIC = b"HCV1"  # iPhone が「画像だ」と見分けるための印
IMAGE_NAME = ".Sumaho Dolly Camera View"  # 先頭の「.」で Blender の一覧に出にくくする


class CameraView:
    def __init__(self):
        self._offscreen = None
        self._size = None
        self._path = os.path.join(tempfile.gettempdir(), f"handcam_view_{os.getpid()}.jpg")
        self.seq = 0
        self.last_bytes = 0
        self.error = ""

    def free(self):
        if self._offscreen is not None:
            self._offscreen.free()
        self._offscreen = None
        self._size = None
        try:
            img = bpy.data.images.get(IMAGE_NAME)
            if img is not None:
                bpy.data.images.remove(img)
        except (AttributeError, RuntimeError):
            pass  # Blender を閉じる途中など、データに触れないとき
        try:
            os.remove(self._path)
        except OSError:
            pass

    @staticmethod
    def frame_size(scene, size_key):
        width = SIZES.get(size_key, SIZES["MEDIUM"])
        rx = scene.render.resolution_x * scene.render.pixel_aspect_x
        ry = scene.render.resolution_y * scene.render.pixel_aspect_y
        height = int(round(width * ry / rx / 2.0)) * 2 if rx > 0 else width * 9 // 16
        return width, max(height, 2)

    def capture(self, context, camera, size_key):
        """カメラから見た画面の JPEG を返す。ヘッダーの描画の中から呼ぶこと。"""
        scene = context.scene
        area = context.area
        window_region = next((r for r in area.regions if r.type == "WINDOW"), None)
        if window_region is None:
            return None
        space = area.spaces.active
        w, h = self.frame_size(scene, size_key)
        if self._size != (w, h):
            if self._offscreen is not None:
                self._offscreen.free()
            self._offscreen = gpu.types.GPUOffScreen(w, h)
            self._size = (w, h)

        depsgraph = context.evaluated_depsgraph_get()
        view = camera.matrix_world.inverted()
        projection = camera.calc_matrix_camera(depsgraph, x=w, y=h)
        show_overlays = space.overlay.show_overlays
        space.overlay.show_overlays = False
        try:
            self._offscreen.draw_view3d(scene, context.view_layer, space, window_region,
                                        view, projection, do_color_management=True)
        finally:
            space.overlay.show_overlays = show_overlays

        pixels = np.asarray(self._offscreen.texture_color.read(), dtype=np.uint8).reshape(-1)
        return self._encode(pixels, w, h)

    def _encode(self, pixels_rgba8, w, h):
        img = bpy.data.images.get(IMAGE_NAME)
        if img is None or tuple(img.size) != (w, h):
            if img is not None:
                bpy.data.images.remove(img)
            img = bpy.data.images.new(IMAGE_NAME, w, h, alpha=False)
        img.pixels.foreach_set(pixels_rgba8.astype(np.float32) / 255.0)
        img.filepath_raw = self._path
        img.file_format = "JPEG"
        for quality in (JPEG_QUALITY, 35):
            img.save(filepath=self._path, quality=quality)
            with open(self._path, "rb") as f:
                data = f.read()
            if len(MAGIC) + 4 + len(data) <= MAX_PACKET:
                return data
        return None  # 大きすぎて1パケットに入らない（画質を下げてもだめ）

    def packet(self, jpeg):
        self.seq = (self.seq + 1) & 0xFFFFFFFF
        self.last_bytes = len(jpeg)
        return MAGIC + struct.pack(">I", self.seq) + jpeg

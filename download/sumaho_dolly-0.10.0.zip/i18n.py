"""画面の言葉の英語・日本語の切り替え。

Blender の言語（プリファレンス → インターフェース → 言語。既定の「自動」なら OS の言語）に合わせる。
コードの中の言葉は英語（msgid）で書き、日本語はこの JA に置く。
ほかのアドオンや Blender 本体の訳とぶつからないよう、決まった文脈（CONTEXT）で登録する。
"""

import bpy

CONTEXT = "SumahoDolly"

# 英語 → 日本語。{} は、あとで中身（テイクの名前や数）を入れる場所。
JA = {
    # --- 設定（N パネルの項目）
    "Camera": "カメラ",
    "The camera moved by the iPhone. If empty, the scene camera is used":
        "iPhone の動きで動かすカメラ。空なら、シーンのカメラを使う",
    "Port": "ポート",
    "Use the same number as in the iPhone app": "iPhone アプリと同じ番号にする",
    "Scale": "縮尺",
    "How many meters the camera moves when the iPhone moves 1 m. Rotation is not affected":
        "iPhone を 1m 動かしたとき、カメラを何 m 動かすか。向きの変わり方は変わらない",
    "Smoothing": "揺れを和らげる",
    "How strongly to smooth out small hand shake. Stronger is smoother but lags a little (up to about 0.5 s). 0 turns it off":
        "手の細かい揺れを抑える強さ。強いほどなめらかだが、少し遅れてついてくる（最大で約0.5秒）。0 で切る",
    "Send View to iPhone": "iPhone に画面を送る",
    "Send what the camera sees to the iPhone as small images. If Blender gets slow, turn it off or lower the quality or frame rate":
        "カメラから見た画面を、小さな画像にして iPhone へ送る。重いときは切るか、画質・枚数を下げる",
    "Quality": "画質",
    "Low (480 wide)": "低（横 480）",
    "Lightest": "いちばん軽い",
    "Medium (640 wide)": "中（横 640）",
    "High (960 wide)": "高（横 960）",
    "Sharpest, but heaviest": "いちばんきれいだが重い",
    "Frames per Second": "1秒あたりの枚数",
    "Higher is smoother but heavier": "多いほどなめらかだが重い",

    # --- ボタン
    "Start Receiving": "受信を始める",
    "Receive motion from the iPhone and apply it to the camera": "iPhone から届く動きを受け取り、カメラに反映する",
    "Stop": "止める",
    "Stop receiving (the camera stays where it is)": "受け取りを止める（カメラは今の位置のまま）",
    "Re-center": "基準を合わせ直す",
    "Match the iPhone's current position and heading to the camera's current position and heading":
        "今の iPhone の位置と水平の向きを、今のカメラの位置と向きに合わせる",
    "Start Recording": "記録を始める",
    "Create a new take and record the camera's motion every frame while playing the timeline from the start":
        "新しいテイクを作り、タイムラインを最初から再生しながら、1フレームごとにカメラの動きを残す",
    "Stop Recording": "記録を止める",
    "Finish recording and keep the take (also stops playback)": "記録を終え、テイクを残す（再生も止める）",
    "Play Back": "見返す",
    "Play the selected take from the start (the iPhone's motion is ignored meanwhile)":
        "選んでいるテイクを最初から再生する（その間、iPhone の動きは反映しない）",
    "Stop Playback": "見返しをやめる",
    "Stop playback and go back to following the iPhone": "再生を止め、iPhone の動きの反映に戻る",
    "Delete This Take": "このテイクを削除",
    "Delete the selected take (it is also removed from the Blender file)":
        "選んでいるテイクを消す（Blender のファイルからも消える）",
    "Delete {}?": "{} を削除しますか？",
    "This can't be undone": "元に戻せません",
    "Delete": "削除",

    # --- パネルの表示
    "(Empty: uses scene camera {})": "（空なのでシーンのカメラ: {}）",
    "None": "なし",
    "This PC's IP: {}": "この PC の IP: {}",
    "Unknown": "不明",
    "Recording": "記録",
    "Recording: {}": "記録中: {}",
    "Frame {} / {}": "フレーム {} / {}",
    "Records frames {}–{} from the start": "フレーム {}〜{} を、最初から記録します",
    "Unsaved: save the file to keep takes": "テイクはファイルを保存すると残ります（未保存）",
    "Take": "テイク",
    "Starts sending once the iPhone connects": "iPhone とつながると送り始めます",
    "Sending {:.0f} images/s · {:.0f} KB each": "送信中 {:.0f}枚/秒・1枚 {:.0f}KB",
    "Stopped": "止まっています",
    "Waiting (port {})": "待っています（ポート {}）",
    "Nothing received (last {:.0f} s ago)": "届いていません（{:.0f}秒前が最後）",
    "Receiving {:.0f}/s": "受信中 {:.0f}回/秒",
    "From: {}": "送り元: {}",
    "Good": "良好",
    "Unstable": "不安定",
    "Not tracking": "読み取れない",
    "iPhone tracking: {}": "iPhone の読み取り: {}",

    # --- お知らせ・断る理由（N パネルと iPhone に出る）
    "Can't open port {}: {}": "ポート {} を開けません: {}",
    "Receive error: {}": "受け取りでエラー: {}",
    "Recording is unlocked by purchasing it in the iPhone app": "記録は iPhone アプリで購入すると使えます",
    "Already recording": "すでに記録中です",
    "Select a camera": "カメラを選んでください",
    "Nothing has arrived from the iPhone yet": "iPhone からまだ届いていません",
    "Can't play back while recording": "記録中は見返せません",
    "No take to play back": "見返すテイクがありません",
    "Kept {} ({} frames)": "{} を残しました（{} フレーム）",
    "{} — {}": "{}・{}",
    "Camera not found": "カメラが見つからない",
    "Recorded to the end of the timeline": "タイムラインの最後まで記録",
    "Playback stopped": "再生が止まった",
    "Receiving stopped": "受信を止めた",
    "Recording {}": "{} を記録しています",
    "Couldn't render the view: {}": "画面を作れませんでした: {}",
    "The view is too large to send (lower the quality)": "画面が大きすぎて送れません（画質を下げてください）",
    "Unknown command: {}": "知らない操作です: {}",
    "Couldn't read the setting values": "設定の値が読めません",
    "Can't change the frame range while recording": "記録中はフレームの範囲を変えられません",
    "The end frame must be after the start frame": "終わりのフレームは、始まりより後にしてください",
    "Can't change takes while recording": "記録中はテイクを変えられません",
    "Take not found: {}": "テイクが見つかりません: {}",
    "Can't delete takes while recording": "記録中はテイクを消せません",
    "Deleted {}": "{} を削除しました",
    "This file has no name yet. Use “Save As” in Blender the first time":
        "まだ名前のないファイルです。最初の1回は Blender で「名前を付けて保存」してください",
    "Can't save while recording": "記録中は保存できません",
    "Couldn't save: {}": "保存できませんでした: {}",
    "Saved {}": "{} を保存しました",

    # --- 元に戻すの履歴
    "Sumaho Dolly: Record {}": "Sumaho Dolly: {} を記録",
    "Sumaho Dolly: Delete {}": "Sumaho Dolly: {} を削除",
}

# Blender が日本語のときの言語コード（Blender 5.2 で確かめた: ja_JP）
LOCALES = ("ja_JP",)


def tr(msgid):
    """今の Blender の言語での言葉。日本語なら JA の訳、ほかは英語のまま。"""
    return bpy.app.translations.pgettext_iface(msgid, CONTEXT)


def _translations():
    table = {}
    for msgid, ja in JA.items():
        table[(CONTEXT, msgid)] = ja
    # 説明文（ツールチップ）は既定の文脈で訳されることがあるので、長い文はそちらにも入れる
    # （短い言葉は Blender 本体の訳とぶつかるので入れない）
    for msgid, ja in JA.items():
        if len(msgid) > 30:
            table[("*", msgid)] = ja
    return {locale: table for locale in LOCALES}


def register(module_name):
    bpy.app.translations.register(module_name, _translations())


def unregister(module_name):
    bpy.app.translations.unregister(module_name)

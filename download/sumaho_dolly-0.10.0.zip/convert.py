"""ARKit の座標を Blender の座標に変える計算（bpy を使わない。mathutils だけ）。

ARKit（世界）: 右手系、Y 軸が上、始めたときの iPhone の向きが -Z。単位はメートル。
Blender（世界）: 右手系、Z 軸が上、正面（前から見た図で奥）が +Y。

両者は「X 軸のまわりに +90 度回す」だけの違い:
    ARKit の +Y（上） → Blender の +Z（上）
    ARKit の -Z（前） → Blender の +Y（前）
    ARKit の +X（右） → Blender の +X（右）

カメラ自身の軸の決まりは、ARKit のカメラも Blender のカメラも同じ
（レンズは自分の -Z を向き、+Y が画面の上、+X が画面の右）。
なので、カメラの姿勢は「世界の軸の変換 @ ARKit の姿勢」でそのまま使える。
※ iPhone を横持ち（画面の上側が左）にしたときに、画面の上下がそろう。
"""

import math

from mathutils import Matrix, Quaternion, Vector

# ARKit の世界 → Blender の世界（X 軸のまわりに +90 度）
AXIS_CONVERSION = Matrix.Rotation(math.radians(90.0), 4, "X")
_AXIS_Q = AXIS_CONVERSION.to_quaternion()
_AXIS_3 = AXIS_CONVERSION.to_3x3()


def arkit_to_blender(p, q):
    """ARKit のカメラの位置 p=(x,y,z) と四元数 q=(x,y,z,w) から、Blender のカメラの matrix_world を作る。"""
    loc = _AXIS_3 @ Vector((p[0], p[1], p[2]))
    rot = _AXIS_Q @ Quaternion((q[3], q[0], q[1], q[2])).normalized()
    return Matrix.LocRotScale(loc, rot, None)


def yaw_of(matrix):
    """カメラが水平方向でどちらを向いているか（Z 軸まわりの角度、ラジアン）。+Y 向きが 0。"""
    m3 = matrix.to_3x3().normalized()
    forward = -m3.col[2]  # カメラのレンズの向き（-Z）
    if math.hypot(forward.x, forward.y) < 1e-3:
        # 真上・真下を向いているときは、画面の上（+Y）の向きで代わりに決める
        forward = m3.col[1]
    return math.atan2(-forward.x, forward.y)


def _yaw_and_location(matrix):
    return Matrix.Translation(matrix.to_translation()) @ Matrix.Rotation(yaw_of(matrix), 4, "Z")


class Alignment:
    """基準合わせ: 合わせた瞬間の iPhone の姿勢を、そのときの Blender のカメラの位置・水平の向きに重ねる。

    傾き（上下・左右の傾き）は重力に合わせたまま残し、位置と水平の向き（ヨー）だけを合わせる。
    縮尺は「合わせた場所からの移動の距離」に掛ける（向きには掛けない）。
    縮尺 2 なら、iPhone を 1m 動かすとカメラは 2m 動く。
    """

    def __init__(self, camera_matrix, pose_matrix):
        self.anchor = _yaw_and_location(camera_matrix)
        self.reference_inv = _yaw_and_location(pose_matrix).inverted()

    def apply(self, pose_matrix, scale=1.0):
        """iPhone の姿勢（Blender の座標に変えたもの）から、カメラの matrix_world を返す。"""
        rel = self.reference_inv @ pose_matrix  # 合わせた瞬間から見た、今の iPhone
        loc, rot, _ = rel.decompose()
        return self.anchor @ Matrix.LocRotScale(loc * scale, rot, None)


# 揺れを和らげる強さ 1.0 のときの「遅れの目安」（秒）。強さ 0.5 なら 1/4 の 0.125 秒。
MAX_SMOOTHING_TIME = 0.5


def smoothing_time(strength):
    """強さ（0〜1）から、なめらかにする時間（秒）を決める。弱い側を細かく選べるように 2 乗にする。"""
    s = min(max(strength, 0.0), 1.0)
    return MAX_SMOOTHING_TIME * s * s


class Smoother:
    """手の細かい揺れを和らげる（位置と向きを、少しずつ新しい値へ近づける）。

    強いほどなめらかになるが、そのぶん少し遅れてついてくる。
    1秒に何回届いても同じ効き方になるよう、届いた時刻の差（dt）で近づく割合を決める。
    """

    def __init__(self):
        self.reset()

    def reset(self):
        self.loc = None
        self.rot = None
        self.t = None

    def apply(self, pose_matrix, t, strength):
        loc, rot, _ = pose_matrix.decompose()
        tau = smoothing_time(strength)
        dt = None if self.t is None else t - self.t
        # 初回・強さ 0・時刻が戻った（iPhone のアプリを開き直した）・大きく途切れたときは、そのまま使う
        if self.loc is None or tau <= 0.0 or dt is None or dt <= 0.0 or dt > 1.0:
            self.loc, self.rot, self.t = loc, rot, t
            return pose_matrix.copy()
        a = 1.0 - math.exp(-dt / tau)
        if self.rot.dot(rot) < 0.0:  # 同じ向きを表す反対側の四元数なら、近い方へそろえる
            rot = -rot
        self.loc = self.loc.lerp(loc, a)
        self.rot = self.rot.slerp(rot, a).normalized()
        self.t = t
        return Matrix.LocRotScale(self.loc, self.rot, None)

"""Sumaho Dolly の Blender 側（受け取り）。

iPhone アプリから UDP で届く位置と向きを、選んだカメラに反映する。
受け取りは bpy.app.timers で回すので、Blender の画面は止まらない。
"""

import json
import os
import socket
import time

import bpy

from . import camera_view, convert, i18n
from .i18n import tr

DEFAULT_PORT = 9870
POLL_INTERVAL = 1.0 / 120.0  # 1秒に120回のぞく（iPhone は60回送ってくる）
REDRAW_INTERVAL = 0.2
STATUS_INTERVAL = 0.2  # iPhone へ状態を返す間隔
MAX_TAKES_IN_STATUS = 20


class _Receiver:
    """受け取りの状態（Blender のファイルには保存しない）。"""

    def __init__(self):
        self.sock = None
        self.port = None
        self.error = ""
        self.sender = ""
        self.last_packet = None  # 最後に受け取った中身（dict）
        self.last_time = 0.0  # 最後に受け取った時刻（time.monotonic）
        self.alignment = None  # 基準合わせ（convert.Alignment）
        self.smoother = convert.Smoother()
        self.last_matrix = None  # 最後にカメラに入れた姿勢（記録のときにキーフレームにする）
        # 記録
        self.recording = False
        self.take = None  # 記録中のテイク（bpy.types.Action）の名前
        self.record_camera = None  # 記録しているカメラの名前
        self.last_keyed_frame = None
        self.keyed_count = 0
        self.last_euler = None
        self.record_started = 0.0
        self.message = ""  # 最後の記録の結果
        # iPhone からの操作と、iPhone への返事
        self.peer = None  # 返事の宛先 (ip, port)
        self.commands = []
        self.cmd_sid = None
        self.cmd_last_id = 0
        self.previewing = False  # テイクを見返し中（iPhone の動きを反映しない）
        self.takes_unsaved = False  # 記録・削除のあと、まだファイルを保存していない
        # カメラの画面を iPhone に送る
        self._last_view = 0.0
        self.view_rate = 0.0
        self._view_count = 0
        self._view_rate_start = 0.0
        self._last_status = 0.0
        self.needs_align = True
        self.count = 0
        self.rate = 0.0
        self._rate_count = 0
        self._rate_start = 0.0
        self._last_redraw = 0.0

    @property
    def running(self):
        return self.sock is not None

    def start(self, port):
        self.stop()
        self.error = ""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.bind(("0.0.0.0", port))
            sock.setblocking(False)
        except OSError as e:
            self.error = tr("Can't open port {}: {}").format(port, e)
            return False
        self.sock = sock
        self.port = port
        self.sender = ""
        self.last_packet = None
        self.last_time = 0.0
        self.needs_align = True
        self.smoother.reset()
        self.last_matrix = None
        self.peer = None
        self.commands = []
        self.cmd_sid = None
        self.cmd_last_id = 0
        self.previewing = False
        self.count = 0
        self.rate = 0.0
        self._rate_count = 0
        self._rate_start = time.monotonic()
        return True

    def send(self, obj):
        if self.sock is None or self.peer is None:
            return
        try:
            self.sock.sendto(json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8"), self.peer)
        except OSError:
            pass  # 返事が送れなくても、受け取りは続ける

    def send_bytes(self, data):
        if self.sock is None or self.peer is None:
            return
        try:
            self.sock.sendto(data, self.peer)
        except OSError:
            pass

    def stop(self):
        if self.sock is not None:
            try:
                self.sock.close()
            except OSError:
                pass
        self.sock = None

    def drain(self):
        """届いている分をすべて読み、いちばん新しい「動き」を返す（なければ None）。操作は self.commands にためる。"""
        latest = None
        for _ in range(1000):
            try:
                data, addr = self.sock.recvfrom(2048)
            except (BlockingIOError, InterruptedError):
                break
            except OSError as e:
                self.error = tr("Receive error: {}").format(e)
                break
            try:
                packet = json.loads(data.decode("utf-8"))
                if not isinstance(packet, dict):
                    continue
                if packet.get("type") == "cmd":
                    self.peer = addr
                    self.commands.append(packet)
                    continue
                p = packet["p"]
                q = packet["q"]
                if len(p) != 3 or len(q) != 4:
                    continue
            except (ValueError, KeyError, TypeError, UnicodeDecodeError):
                continue
            latest = packet
            self.peer = addr
            self.sender = addr[0]
            self.count += 1
            self._rate_count += 1

        now = time.monotonic()
        if now - self._rate_start >= 1.0:
            self.rate = self._rate_count / (now - self._rate_start)
            self._rate_count = 0
            self._rate_start = now
        if latest is not None:
            self.last_packet = latest
            self.last_time = now
        return latest


receiver = _Receiver()


def target_camera(scene):
    cam = scene.handcam.camera
    if cam is None:
        cam = scene.camera
    if cam is not None and cam.type == "CAMERA":
        return cam
    return None


def apply_packet(scene, packet):
    """受け取った1つ分を、カメラに反映する。反映したら True。"""
    if packet.get("track") == "notAvailable" or receiver.previewing:
        return False
    cam = target_camera(scene)
    if cam is None:
        return False
    pose = convert.arkit_to_blender(packet["p"], packet["q"])
    try:
        t = float(packet.get("t", 0.0))
    except (TypeError, ValueError):
        t = 0.0
    pose = receiver.smoother.apply(pose, t, scene.handcam.smoothing)
    if receiver.needs_align or receiver.alignment is None:
        receiver.alignment = convert.Alignment(cam.matrix_world, pose)
        receiver.needs_align = False
    receiver.last_matrix = receiver.alignment.apply(pose, scene.handcam.scale)
    cam.matrix_world = receiver.last_matrix
    return True


# ---------------------------------------------------------------- 記録（テイクごとにアクションとして残す）

TAKE_GROUP = "Sumaho Dolly"


def _rotation_path(obj):
    mode = obj.rotation_mode
    if mode == "QUATERNION":
        return "rotation_quaternion"
    if mode == "AXIS_ANGLE":
        return "rotation_axis_angle"
    return "rotation_euler"


def next_take_name(cam):
    prefix = f"{cam.name}_Take_"
    used = set()
    for act in bpy.data.actions:
        if act.name.startswith(prefix) and act.name[len(prefix):].isdigit():
            used.add(int(act.name[len(prefix):]))
    n = 1
    while n in used:
        n += 1
    return f"{prefix}{n:03d}"


def _playing_screens():
    wm = bpy.context.window_manager
    if wm is None:
        return []
    return [(w, w.screen) for w in wm.windows if w.screen and w.screen.is_animation_playing]


def _has_windows():
    # 画面なしの起動（自動テスト）では再生しないので、「再生が止まったら終える」を使わない
    wm = bpy.context.window_manager
    return not bpy.app.background and wm is not None and len(wm.windows) > 0


def _stop_playback():
    for window, screen in _playing_screens():
        try:
            with bpy.context.temp_override(window=window, screen=screen):
                bpy.ops.screen.animation_cancel(restore_frame=False)
        except RuntimeError:
            pass


def _start_playback():
    """タイムラインの再生を始める（ボタンからでも、iPhone の操作からでも動くように、窓を指定して呼ぶ）。"""
    if bpy.app.background or _playing_screens():
        return
    wm = bpy.context.window_manager
    for window in wm.windows if wm else []:
        if window.screen is None:
            continue
        try:
            with bpy.context.temp_override(window=window, screen=window.screen):
                bpy.ops.screen.animation_play()
            return
        except RuntimeError:
            continue


def takes_for(cam):
    """そのカメラのテイク（新しい順）。"""
    prefix = f"{cam.name}_Take_"
    found = []
    for act in bpy.data.actions:
        rest = act.name[len(prefix):]
        if act.name.startswith(prefix) and rest.isdigit():
            found.append((int(rest), act.name))
    return [name for _, name in sorted(found, reverse=True)]


LOCKED_MESSAGE = "Recording is unlocked by purchasing it in the iPhone app"  # 出すときに tr() で訳す


def recording_allowed():
    """つながっている iPhone アプリで記録が買われているか（動きの「rec」が 1）。docs/protocol.md"""
    return bool(receiver.last_packet and receiver.last_packet.get("rec"))


def begin_recording(scene):
    """記録を始める（N パネルのボタンと iPhone の操作の共通）。始めたら None、だめなら理由を返す。"""
    if receiver.recording:
        return tr("Already recording")
    cam = target_camera(scene)
    if cam is None:
        return tr("Select a camera")
    if receiver.last_packet is None:
        return tr("Nothing has arrived from the iPhone yet")
    if not recording_allowed():
        return tr(LOCKED_MESSAGE)
    stop_preview()
    _stop_playback()
    start_recording(scene, cam)
    _start_playback()
    return None


def start_preview(scene):
    """選んでいるテイクを、最初から再生して見返す。その間は iPhone の動きを反映しない。"""
    if receiver.recording:
        return tr("Can't play back while recording")
    cam = target_camera(scene)
    if cam is None or cam.animation_data is None or cam.animation_data.action is None:
        return tr("No take to play back")
    receiver.previewing = True
    _stop_playback()
    scene.frame_set(scene.frame_start)
    _start_playback()
    return None


def stop_preview():
    if not receiver.previewing:
        return
    receiver.previewing = False
    _stop_playback()
    receiver.needs_align = True  # 見返している間に iPhone が動いても、カメラが飛ばないように合わせ直す


def start_recording(scene, cam):
    """新しいテイクを作り、タイムラインの最初のフレームから記録を始める。"""
    name = next_take_name(cam)
    act = bpy.data.actions.new(name)
    act.use_fake_user = True  # 使っていないテイクも、ファイルを保存したときに消えないように
    if cam.animation_data is None:
        cam.animation_data_create()
    cam.animation_data.action = act
    receiver.recording = True
    receiver.take = act.name
    receiver.record_camera = cam.name
    receiver.last_keyed_frame = None
    receiver.keyed_count = 0
    receiver.last_euler = None
    receiver.record_started = time.monotonic()
    receiver.message = ""
    scene.frame_set(scene.frame_start)
    return act


def mark_changed(label):
    """「ファイルが変わった」と Blender に知らせる（元に戻す履歴に1つ積む）。
    Python から変えただけだと Blender は気づかず、閉じるときの「保存しますか？」が出ないため。"""
    receiver.takes_unsaved = True
    wm = bpy.context.window_manager
    windows = list(wm.windows) if wm else []
    try:
        if windows:
            with bpy.context.temp_override(window=windows[0]):
                bpy.ops.ed.undo_push(message=label)
        else:
            bpy.ops.ed.undo_push(message=label)
    except RuntimeError:
        pass


def finish_recording(reason=""):
    if not receiver.recording:
        return
    receiver.recording = False
    _stop_playback()
    msg = tr("Kept {} ({} frames)").format(receiver.take, receiver.keyed_count)
    mark_changed(tr("Sumaho Dolly: Record {}").format(receiver.take))
    receiver.message = tr("{} — {}").format(msg, tr(reason)) if reason else msg


@bpy.app.handlers.persistent
def _on_frame_change(scene, depsgraph=None):
    # 記録中は、フレームが変わってもテイクの値に戻らず、iPhone の今の姿勢を見せ続ける（画面のちらつきを防ぐ）
    if not receiver.recording or receiver.last_matrix is None:
        return
    cam = bpy.data.objects.get(receiver.record_camera or "")
    if cam is not None:
        cam.matrix_world = receiver.last_matrix


def record_tick(scene):
    """記録中なら、今のフレームにキーフレームを打つ。タイムラインの最後まで行ったら終える。"""
    if not receiver.recording:
        return
    cam = bpy.data.objects.get(receiver.record_camera or "")
    if cam is None:
        finish_recording("Camera not found")
        return
    frame = scene.frame_current
    last = receiver.last_keyed_frame
    if last is not None and frame < last:
        finish_recording("Recorded to the end of the timeline")  # 再生が最初に戻った
        return
    if (_has_windows() and not _playing_screens()
            and time.monotonic() - receiver.record_started > 0.5):
        finish_recording("Playback stopped")
        return
    if frame == last or receiver.last_matrix is None:
        return
    # フレームが進むと、Blender がテイクの値でカメラを動かしてしまうので、最新の姿勢を入れ直してから打つ
    cam.matrix_world = receiver.last_matrix
    path = _rotation_path(cam)
    if path == "rotation_euler":
        m3 = cam.matrix_basis.to_3x3().normalized()
        if receiver.last_euler is not None:
            cam.rotation_euler = m3.to_euler(cam.rotation_mode, receiver.last_euler)  # 一回転して飛ばないように
        receiver.last_euler = cam.rotation_euler.copy()
    cam.keyframe_insert("location", frame=frame, group=TAKE_GROUP)
    cam.keyframe_insert(path, frame=frame, group=TAKE_GROUP)
    receiver.last_keyed_frame = frame
    receiver.keyed_count += 1


def _redraw_panels():
    wm = bpy.context.window_manager
    if wm is None:
        return
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


view = camera_view.CameraView()


def _view_wanted(scene):
    return (receiver.running and receiver.peer is not None and scene is not None
            and scene.handcam.view_enabled)


def _draw_view_handler():
    """3D ビューのヘッダーが描かれるときに呼ばれる。時間が来ていれば、カメラの画面を1枚送る。"""
    context = bpy.context
    scene = context.scene
    if not _view_wanted(scene):
        return
    now = time.monotonic()
    if now - receiver._last_view < 0.85 / max(scene.handcam.view_fps, 1):
        return
    cam = target_camera(scene)
    if cam is None:
        return
    receiver._last_view = now  # 3D ビューがいくつあっても、1回ぶんだけ送る
    try:
        jpeg = view.capture(context, cam, scene.handcam.view_size)
    except Exception as e:  # 描けなくても、受け取りや記録は止めない
        view.error = tr("Couldn't render the view: {}").format(e)
        return
    if jpeg is None:
        view.error = tr("The view is too large to send (lower the quality)")
        return
    view.error = ""
    receiver.send_bytes(view.packet(jpeg))
    receiver._view_count += 1
    if now - receiver._view_rate_start >= 1.0:
        receiver.view_rate = receiver._view_count / (now - receiver._view_rate_start)
        receiver._view_count = 0
        receiver._view_rate_start = now


def _tag_headers_for_view():
    """送る時間が来たら、3D ビューのヘッダーだけを描き直させる（ビューポート本体は描き直さない）。"""
    wm = bpy.context.window_manager
    if wm is None:
        return
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                for region in area.regions:
                    if region.type == "HEADER":
                        region.tag_redraw()
                return  # 1つで十分


def _timer():
    if not receiver.running:
        return None
    packet = receiver.drain()
    scene = bpy.context.scene
    if packet is not None and scene is not None:
        apply_packet(scene, packet)
    if scene is not None:
        for cmd in receiver.commands:
            handle_command(scene, cmd)
        record_tick(scene)
        if receiver.previewing and _has_windows() and not _playing_screens():
            stop_preview()  # Blender 側で再生を止めたら、見返しも終わり
    had_commands = bool(receiver.commands)
    receiver.commands = []
    now = time.monotonic()
    if _view_wanted(scene) and now - receiver._last_view >= 0.85 / max(scene.handcam.view_fps, 1):
        _tag_headers_for_view()
    if scene is not None and receiver.peer is not None and (
            had_commands or now - receiver._last_status >= STATUS_INTERVAL):
        receiver._last_status = now
        receiver.send(build_status(scene))
    if now - receiver._last_redraw >= REDRAW_INTERVAL:
        receiver._last_redraw = now
        _redraw_panels()
    return POLL_INTERVAL


# ---------------------------------------------------------------- iPhone からの操作と、iPhone への返事（docs/protocol.md）


def handle_command(scene, packet):
    sid = str(packet.get("sid", ""))
    try:
        cid = int(packet.get("id", 0))
    except (TypeError, ValueError):
        return
    if sid != receiver.cmd_sid:  # iPhone で送信をやり直した
        receiver.cmd_sid = sid
        receiver.cmd_last_id = 0
    if cid <= receiver.cmd_last_id:
        return  # 送り直されたもの。もうやったので、返事だけ返す
    receiver.cmd_last_id = cid
    cmd = packet.get("cmd")
    args = packet.get("args") or {}
    if not isinstance(args, dict):
        args = {}
    error = None
    if cmd == "record_start":
        error = begin_recording(scene)
    elif cmd == "record_stop":
        finish_recording()
    elif cmd == "realign":
        receiver.needs_align = True
    elif cmd == "set":
        error = _apply_settings(scene, args)
    elif cmd == "take_select":
        error = _select_take(scene, str(args.get("name", "")))
    elif cmd == "preview_start":
        error = start_preview(scene)
    elif cmd == "preview_stop":
        stop_preview()
    elif cmd == "take_delete":
        error = delete_take(scene, str(args.get("name", "")))
    elif cmd == "save_file":
        error = save_file()
    else:
        error = tr("Unknown command: {}").format(cmd)
    if error:
        receiver.message = error


def _apply_settings(scene, args):
    settings = scene.handcam
    try:
        if "scale" in args:
            settings.scale = min(max(float(args["scale"]), 0.1), 10.0)
        if "smoothing" in args:
            settings.smoothing = min(max(float(args["smoothing"]), 0.0), 1.0)
        start = int(args.get("frame_start", scene.frame_start))
        end = int(args.get("frame_end", scene.frame_end))
    except (TypeError, ValueError):
        return tr("Couldn't read the setting values")
    try:
        if "view_enabled" in args:
            settings.view_enabled = bool(args["view_enabled"])
        if "view_size" in args and str(args["view_size"]) in camera_view.SIZES:
            settings.view_size = str(args["view_size"])
        if "view_fps" in args:
            settings.view_fps = min(max(int(args["view_fps"]), 1), 30)
    except (TypeError, ValueError):
        return tr("Couldn't read the setting values")
    if "frame_start" in args or "frame_end" in args:
        if receiver.recording:
            return tr("Can't change the frame range while recording")
        start = max(start, 0)
        if end <= start:
            return tr("The end frame must be after the start frame")
        scene.frame_start = start
        scene.frame_end = end
    return None


def _select_take(scene, name):
    if receiver.recording:
        return tr("Can't change takes while recording")
    cam = target_camera(scene)
    act = bpy.data.actions.get(name)
    if cam is None or act is None or name not in takes_for(cam):
        return tr("Take not found: {}").format(name)
    if cam.animation_data is None:
        cam.animation_data_create()
    cam.animation_data.action = act
    return None


def delete_take(scene, name):
    """テイクを消す（Blender のファイルからも消える。元に戻せない）。消したら None、だめなら理由を返す。"""
    if receiver.recording:
        return tr("Can't delete takes while recording")
    cam = target_camera(scene)
    act = bpy.data.actions.get(name)
    if cam is None or act is None or name not in takes_for(cam):
        return tr("Take not found: {}").format(name)
    was_current = cam.animation_data is not None and cam.animation_data.action == act
    if was_current:
        stop_preview()
        cam.animation_data.action = None
    bpy.data.actions.remove(act)
    if was_current:
        rest = takes_for(cam)
        if rest:  # 続けて見比べ・削除ができるよう、いちばん新しい残りのテイクを選んでおく
            cam.animation_data.action = bpy.data.actions[rest[0]]
    receiver.message = tr("Deleted {}").format(name)
    mark_changed(tr("Sumaho Dolly: Delete {}").format(name))
    return None


def file_state():
    """Blender のファイルの保存の状態: (名前 or None, テイクが保存済みか)
    bpy.data.is_dirty は保存の直後にすぐ戻らないことがあるので、記録・削除と保存を自分で数える。"""
    path = bpy.data.filepath
    name = os.path.basename(path) if path else None
    return name, bool(path) and not receiver.takes_unsaved


@bpy.app.handlers.persistent
def _on_saved_or_loaded(*_args):
    receiver.takes_unsaved = False


def save_file():
    """今の Blender のファイルを上書き保存する。名前がまだないときは保存できない。"""
    if not bpy.data.filepath:
        return tr("This file has no name yet. Use \u201cSave As\u201d in Blender the first time")
    if receiver.recording:
        return tr("Can't save while recording")
    wm = bpy.context.window_manager
    windows = list(wm.windows) if wm else []
    try:
        if windows:
            with bpy.context.temp_override(window=windows[0]):
                bpy.ops.wm.save_mainfile()
        else:
            bpy.ops.wm.save_mainfile()
    except RuntimeError as e:
        return tr("Couldn't save: {}").format(e)
    receiver.message = tr("Saved {}").format(os.path.basename(bpy.data.filepath))
    return None


def build_status(scene):
    cam = target_camera(scene)
    file_name, file_saved = file_state()
    take = None
    takes = []
    if cam is not None:
        takes = takes_for(cam)[:MAX_TAKES_IN_STATUS]
        if cam.animation_data is not None and cam.animation_data.action is not None:
            take = cam.animation_data.action.name
    if receiver.recording:
        mode = "recording"
        take = receiver.take
    elif receiver.previewing:
        mode = "preview"
    else:
        mode = "live"
    return {
        "v": 1,
        "type": "status",
        "sid": receiver.cmd_sid,
        "ack": receiver.cmd_last_id,
        "camera": cam.name if cam is not None else None,
        "mode": mode,
        "take": take,
        "takes": takes,
        "frame": scene.frame_current,
        "frame_start": scene.frame_start,
        "frame_end": scene.frame_end,
        "fps": round(scene.render.fps / (scene.render.fps_base or 1.0), 3),
        "scale": round(scene.handcam.scale, 3),
        "smoothing": round(scene.handcam.smoothing, 3),
        "message": receiver.message,
        "file_name": file_name,
        "file_saved": file_saved,
        "view_enabled": scene.handcam.view_enabled,
        "view_size": scene.handcam.view_size,
        "view_fps": scene.handcam.view_fps,
        "can_record": recording_allowed(),
    }


def local_ip():
    """この PC の LAN の IP（iPhone に入力する宛先）。パケットは送らない。"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return tr("Unknown")
    finally:
        s.close()


# ---------------------------------------------------------------- 設定


def _poll_camera(self, obj):
    return obj.type == "CAMERA"


def _on_scale_changed(self, context):
    # 縮尺は「合わせた場所からの距離」に掛けるので、変えたらその場で合わせ直す（カメラが飛ばないように）
    receiver.needs_align = True


def _on_view_toggled(self, context):
    if not self.view_enabled:
        view.free()
    receiver.view_rate = 0.0
    receiver._view_count = 0
    receiver._view_rate_start = time.monotonic()


class HandCamSettings(bpy.types.PropertyGroup):
    camera: bpy.props.PointerProperty(
        name="Camera",
        translation_context=i18n.CONTEXT,
        description="The camera moved by the iPhone. If empty, the scene camera is used",
        type=bpy.types.Object,
        poll=_poll_camera,
    )
    port: bpy.props.IntProperty(
        name="Port",
        translation_context=i18n.CONTEXT,
        description="Use the same number as in the iPhone app",
        default=DEFAULT_PORT,
        min=1024,
        max=65535,
    )
    scale: bpy.props.FloatProperty(
        name="Scale",
        translation_context=i18n.CONTEXT,
        description="How many meters the camera moves when the iPhone moves 1 m. Rotation is not affected",
        default=1.0,
        min=0.1,
        max=10.0,
        step=10,
        precision=2,
        update=_on_scale_changed,
    )
    smoothing: bpy.props.FloatProperty(
        name="Smoothing",
        translation_context=i18n.CONTEXT,
        description="How strongly to smooth out small hand shake. Stronger is smoother but lags a little (up to about 0.5 s). 0 turns it off",
        default=0.3,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
    )
    view_enabled: bpy.props.BoolProperty(
        name="Send View to iPhone",
        translation_context=i18n.CONTEXT,
        description="Send what the camera sees to the iPhone as small images. If Blender gets slow, turn it off or lower the quality or frame rate",
        default=False,
        update=_on_view_toggled,
    )
    view_size: bpy.props.EnumProperty(
        name="Quality",
        translation_context=i18n.CONTEXT,
        items=[
            ("SMALL", "Low (480 wide)", "Lightest"),
            ("MEDIUM", "Medium (640 wide)", ""),
            ("LARGE", "High (960 wide)", "Sharpest, but heaviest"),
        ],
        default="MEDIUM",
    )
    view_fps: bpy.props.IntProperty(
        name="Frames per Second",
        translation_context=i18n.CONTEXT,
        description="Higher is smoother but heavier",
        default=15,
        min=1,
        max=30,
    )


# ---------------------------------------------------------------- 操作


class HANDCAM_OT_start(bpy.types.Operator):
    bl_idname = "handcam.start"
    bl_label = "Start Receiving"
    bl_translation_context = i18n.CONTEXT
    bl_description = "Receive motion from the iPhone and apply it to the camera"

    def execute(self, context):
        if target_camera(context.scene) is None:
            self.report({"WARNING"}, tr("Select a camera"))
            return {"CANCELLED"}
        if not receiver.start(context.scene.handcam.port):
            self.report({"ERROR"}, receiver.error)
            return {"CANCELLED"}
        if not bpy.app.timers.is_registered(_timer):
            bpy.app.timers.register(_timer, first_interval=POLL_INTERVAL, persistent=True)
        return {"FINISHED"}


class HANDCAM_OT_stop(bpy.types.Operator):
    bl_idname = "handcam.stop"
    bl_label = "Stop"
    bl_translation_context = i18n.CONTEXT
    bl_description = "Stop receiving (the camera stays where it is)"

    def execute(self, context):
        finish_recording("Receiving stopped")
        stop_preview()
        receiver.stop()
        if bpy.app.timers.is_registered(_timer):
            bpy.app.timers.unregister(_timer)
        return {"FINISHED"}


class HANDCAM_OT_realign(bpy.types.Operator):
    bl_idname = "handcam.realign"
    bl_label = "Re-center"
    bl_translation_context = i18n.CONTEXT
    bl_description = "Match the iPhone's current position and heading to the camera's current position and heading"

    def execute(self, context):
        receiver.needs_align = True
        return {"FINISHED"}


class HANDCAM_OT_record_start(bpy.types.Operator):
    bl_idname = "handcam.record_start"
    bl_label = "Start Recording"
    bl_translation_context = i18n.CONTEXT
    bl_description = "Create a new take and record the camera's motion every frame while playing the timeline from the start"

    @classmethod
    def poll(cls, context):
        return receiver.running and not receiver.recording

    def execute(self, context):
        error = begin_recording(context.scene)
        if error:
            self.report({"WARNING"}, error)
            return {"CANCELLED"}
        self.report({"INFO"}, tr("Recording {}").format(receiver.take))
        return {"FINISHED"}


class HANDCAM_OT_record_stop(bpy.types.Operator):
    bl_idname = "handcam.record_stop"
    bl_label = "Stop Recording"
    bl_translation_context = i18n.CONTEXT
    bl_description = "Finish recording and keep the take (also stops playback)"

    @classmethod
    def poll(cls, context):
        return receiver.recording

    def execute(self, context):
        finish_recording()
        self.report({"INFO"}, receiver.message)
        return {"FINISHED"}


class HANDCAM_OT_preview_start(bpy.types.Operator):
    bl_idname = "handcam.preview_start"
    bl_label = "Play Back"
    bl_translation_context = i18n.CONTEXT
    bl_description = "Play the selected take from the start (the iPhone's motion is ignored meanwhile)"

    @classmethod
    def poll(cls, context):
        return receiver.running and not receiver.recording and not receiver.previewing

    def execute(self, context):
        error = start_preview(context.scene)
        if error:
            self.report({"WARNING"}, error)
            return {"CANCELLED"}
        return {"FINISHED"}


class HANDCAM_OT_preview_stop(bpy.types.Operator):
    bl_idname = "handcam.preview_stop"
    bl_label = "Stop Playback"
    bl_translation_context = i18n.CONTEXT
    bl_description = "Stop playback and go back to following the iPhone"

    @classmethod
    def poll(cls, context):
        return receiver.previewing

    def execute(self, context):
        stop_preview()
        return {"FINISHED"}


class HANDCAM_OT_take_delete(bpy.types.Operator):
    bl_idname = "handcam.take_delete"
    bl_label = "Delete This Take"
    bl_translation_context = i18n.CONTEXT
    bl_description = "Delete the selected take (it is also removed from the Blender file)"

    @classmethod
    def poll(cls, context):
        cam = target_camera(context.scene)
        return (not receiver.recording and cam is not None and cam.animation_data is not None
                and cam.animation_data.action is not None
                and cam.animation_data.action.name in takes_for(cam))

    def invoke(self, context, event):
        name = target_camera(context.scene).animation_data.action.name
        return context.window_manager.invoke_confirm(
            self, event, title=tr("Delete {}?").format(name), message=tr("This can't be undone"), confirm_text=tr("Delete"),
            icon="WARNING")

    def execute(self, context):
        name = target_camera(context.scene).animation_data.action.name
        error = delete_take(context.scene, name)
        if error:
            self.report({"WARNING"}, error)
            return {"CANCELLED"}
        self.report({"INFO"}, receiver.message)
        return {"FINISHED"}


# ---------------------------------------------------------------- パネル（N キーのサイドバー）


class HANDCAM_PT_panel(bpy.types.Panel):
    bl_label = "Sumaho Dolly"
    bl_translation_context = i18n.CONTEXT
    bl_idname = "HANDCAM_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Sumaho Dolly"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.handcam

        col = layout.column()
        col.prop(settings, "camera")
        if settings.camera is None:
            name = context.scene.camera.name if context.scene.camera else tr("None")
            col.label(text=tr("(Empty: uses scene camera {})").format(name), translate=False)
        # iPhone の「つなぐ先」と同じ並び（IP → ポート）。縮尺と揺れを和らげるは iPhone で変える
        col.separator()
        col.label(text=tr("This PC's IP: {}").format(local_ip()), icon="URL", translate=False)
        row = col.row()
        row.enabled = not receiver.running
        row.prop(settings, "port")

        layout.separator()
        if receiver.running:
            layout.operator("handcam.stop", icon="PAUSE")
            layout.operator("handcam.realign", icon="ORIENTATION_GIMBAL")
        else:
            layout.operator("handcam.start", icon="PLAY")

        rec = layout.box()
        rec.label(text=tr("Recording"), translate=False)
        if receiver.recording:
            row = rec.row()
            row.alert = True
            row.scale_y = 1.4
            row.operator("handcam.record_stop", icon="SNAP_FACE")
            scene = context.scene
            rec.label(text=tr("Recording: {}").format(receiver.take), icon="REC", translate=False)
            rec.label(text=tr("Frame {} / {}").format(scene.frame_current, scene.frame_end), translate=False)
        else:
            row = rec.row()
            row.scale_y = 1.4
            row.operator("handcam.record_start", icon="REC")
            if receiver.last_packet is not None and not recording_allowed():
                rec.label(text=tr(LOCKED_MESSAGE), icon="LOCKED", translate=False)
            rec.label(text=tr("Records frames {}–{} from the start").format(context.scene.frame_start, context.scene.frame_end),
                      translate=False)
            if receiver.message:
                rec.label(text=receiver.message, icon="CHECKMARK", translate=False)
            name, saved = file_state()
            if not saved:
                rec.label(text=tr("Unsaved: save the file to keep takes"), icon="ERROR", translate=False)
            cam = target_camera(context.scene)
            if cam is not None and cam.animation_data is not None:
                row = rec.row(align=True)
                row.prop(cam.animation_data, "action", text=tr("Take"), translate=False)
                row.operator("handcam.take_delete", text="", icon="TRASH")
                if receiver.previewing:
                    rec.operator("handcam.preview_stop", icon="PAUSE")
                elif receiver.running:
                    rec.operator("handcam.preview_start", icon="PLAY")

        vbox = layout.box()
        vbox.prop(settings, "view_enabled")
        sub = vbox.column()
        sub.enabled = settings.view_enabled
        sub.prop(settings, "view_size")
        sub.prop(settings, "view_fps")
        if settings.view_enabled and receiver.running:
            if view.error:
                vbox.label(text=view.error, icon="ERROR", translate=False)
            elif receiver.peer is None:
                vbox.label(text=tr("Starts sending once the iPhone connects"), icon="TIME", translate=False)
            else:
                vbox.label(text=tr("Sending {:.0f} images/s · {:.0f} KB each").format(receiver.view_rate, view.last_bytes / 1024),
                           translate=False)

        box = layout.box()
        if receiver.error:
            box.label(text=receiver.error, icon="ERROR", translate=False)
        if not receiver.running:
            box.label(text=tr("Stopped"), icon="RADIOBUT_OFF", translate=False)
            return
        age = time.monotonic() - receiver.last_time if receiver.last_packet else None
        if age is None:
            box.label(text=tr("Waiting (port {})").format(receiver.port), icon="TIME", translate=False)
        elif age > 1.0:
            box.label(text=tr("Nothing received (last {:.0f} s ago)").format(age), icon="ERROR", translate=False)
        else:
            box.label(text=tr("Receiving {:.0f}/s").format(receiver.rate), icon="CHECKMARK", translate=False)
            box.label(text=tr("From: {}").format(receiver.sender), translate=False)
            track = receiver.last_packet.get("track", "?")
            track_text = {"normal": tr("Good"), "limited": tr("Unstable"), "notAvailable": tr("Not tracking")}.get(track, track)
            box.label(text=tr("iPhone tracking: {}").format(track_text), translate=False)


classes = (
    HandCamSettings,
    HANDCAM_OT_start,
    HANDCAM_OT_stop,
    HANDCAM_OT_realign,
    HANDCAM_OT_record_start,
    HANDCAM_OT_record_stop,
    HANDCAM_OT_preview_start,
    HANDCAM_OT_preview_stop,
    HANDCAM_OT_take_delete,
    HANDCAM_PT_panel,
)


_view_handle = None


def register():
    i18n.register(__name__)
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.handcam = bpy.props.PointerProperty(type=HandCamSettings)
    bpy.app.handlers.frame_change_post.append(_on_frame_change)
    global _view_handle
    _view_handle = bpy.types.SpaceView3D.draw_handler_add(_draw_view_handler, (), "HEADER", "POST_PIXEL")
    bpy.app.handlers.save_post.append(_on_saved_or_loaded)
    bpy.app.handlers.load_post.append(_on_saved_or_loaded)


def unregister():
    finish_recording()
    receiver.stop()
    global _view_handle
    if _view_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_view_handle, "HEADER")
        _view_handle = None
    view.free()
    if _on_frame_change in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(_on_frame_change)
    for handlers in (bpy.app.handlers.save_post, bpy.app.handlers.load_post):
        if _on_saved_or_loaded in handlers:
            handlers.remove(_on_saved_or_loaded)
    if bpy.app.timers.is_registered(_timer):
        bpy.app.timers.unregister(_timer)
    del bpy.types.Scene.handcam
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    i18n.unregister(__name__)
